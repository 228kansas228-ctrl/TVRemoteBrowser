package com.example.tvremotebrowser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/** Decorative pointer overlay. Remote D-pad and taps are handled by MainActivity. */
public final class RemoteCursorView extends View {
    private final Paint outer = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint center = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float x = 0;
    private float y = 0;
    private boolean initialized = false;

    public RemoteCursorView(Context context) {
        super(context);
        outer.setColor(Color.BLACK);
        outer.setStyle(Paint.Style.STROKE);
        outer.setStrokeWidth(px(5));
        inner.setColor(Color.rgb(111, 239, 216));
        inner.setStyle(Paint.Style.STROKE);
        inner.setStrokeWidth(px(3));
        center.setColor(Color.WHITE);
        center.setStyle(Paint.Style.FILL);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private float px(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (!initialized) {
            x = w / 2f;
            y = h / 2f;
            initialized = true;
        } else {
            x = Math.max(px(10), Math.min(w - px(10), x));
            y = Math.max(px(10), Math.min(h - px(10), y));
        }
    }

    public void move(float dx, float dy) {
        float margin = px(14);
        x = Math.max(margin, Math.min(getWidth() - margin, x + dx));
        y = Math.max(margin, Math.min(getHeight() - margin, y + dy));
        invalidate();
    }

    public float getCursorX() { return x; }
    public float getCursorY() { return y; }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float r = px(13);
        canvas.drawCircle(x, y, r + px(1), outer);
        canvas.drawCircle(x, y, r, inner);
        canvas.drawCircle(x, y, px(3.5f), center);
        canvas.drawLine(x - px(22), y, x - px(15), y, outer);
        canvas.drawLine(x + px(15), y, x + px(22), y, outer);
        canvas.drawLine(x, y - px(22), x, y - px(15), outer);
        canvas.drawLine(x, y + px(15), x, y + px(22), outer);
    }
}
