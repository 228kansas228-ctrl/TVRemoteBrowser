package com.example.tvremotebrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Small Android TV browser that works with a five-button remote.
 * No external Android libraries are required.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "tv_browser_prefs";
    private static final String HOME_URL = "https://tv-browser.invalid/";
    private static final String SEARCH_URL = "https://www.google.com/search?q=";
    private static final int BG = Color.rgb(18, 24, 36);
    private static final int PANEL = Color.rgb(32, 42, 59);
    private static final int ACCENT = Color.rgb(105, 226, 204);

    private LinearLayout root;
    private HorizontalScrollView toolbarScroll;
    private FrameLayout pageFrame;
    private WebView webView;
    private RemoteCursorView cursor;
    private EditText addressBar;
    private Button backButton;
    private Button forwardButton;
    private Button bookmarkButton;
    private Button pointerButton;
    private ProgressBar progressBar;
    private View fullScreenView;
    private WebChromeClient.CustomViewCallback fullScreenCallback;
    private SharedPreferences preferences;
    private String defaultUserAgent;
    private boolean cursorMode = true;
    private boolean desktopMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        desktopMode = preferences.getBoolean("desktop", false);
        buildUi();
        if (webView == null) return;
        configureWebView();
        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        }
        if (webView.getUrl() == null) {
            String last = preferences.getString("last_url", "");
            if (isHttpUrl(last)) navigate(last);
            else showHome();
        }
        setCursorMode(true);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setFocusableInTouchMode(true);
        setContentView(root);

        toolbarScroll = new HorizontalScrollView(this);
        toolbarScroll.setFillViewport(true);
        toolbarScroll.setHorizontalScrollBarEnabled(false);
        toolbarScroll.setBackgroundColor(BG);
        root.addView(toolbarScroll, new LinearLayout.LayoutParams(-1, dp(69)));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8), dp(5), dp(8), dp(5));
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbarScroll.addView(toolbar, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        backButton = addButton(toolbar, "◀", "Назад", 54, () -> {
            if (webView.canGoBack()) webView.goBack();
            else showHome();
        });
        forwardButton = addButton(toolbar, "▶", "Вперёд", 54, () -> {
            if (webView.canGoForward()) webView.goForward();
        });
        addButton(toolbar, "⌂", "Домой", 54, this::showHome);
        addButton(toolbar, "⟳", "Обновить", 54, () -> webView.reload());

        addressBar = new EditText(this);
        addressBar.setSingleLine(true);
        addressBar.setTextSize(18);
        addressBar.setTextColor(Color.WHITE);
        addressBar.setHintTextColor(Color.rgb(159, 173, 192));
        addressBar.setHint("Адрес сайта или поисковый запрос");
        addressBar.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressBar.setSelectAllOnFocus(true);
        addressBar.setPadding(dp(14), 0, dp(14), 0);
        addressBar.setBackground(fieldBackground());
        LinearLayout.LayoutParams fieldParams = new LinearLayout.LayoutParams(dp(365), dp(52));
        fieldParams.setMargins(dp(6), 0, dp(6), 0);
        toolbar.addView(addressBar, fieldParams);
        addressBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER &&
                            event.getAction() == KeyEvent.ACTION_DOWN)) {
                searchOrNavigate(addressBar.getText().toString());
                return true;
            }
            return false;
        });
        addButton(toolbar, "OK", "Перейти", 57, () -> searchOrNavigate(addressBar.getText().toString()));
        bookmarkButton = addButton(toolbar, "☆", "Добавить в закладки", 56, this::toggleBookmark);
        addButton(toolbar, "★", "Закладки", 58, this::showBookmarks);
        pointerButton = addButton(toolbar, "Курсор", "Режим курсора", 116,
                () -> setCursorMode(!cursorMode));
        addButton(toolbar, "⋮", "Настройки и помощь", 54, this::showMenu);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(3)));

        pageFrame = new FrameLayout(this);
        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        root.addView(pageFrame, webParams);

        try {
            webView = new WebView(this);
        } catch (RuntimeException error) {
            Toast.makeText(this, "На устройстве недоступен Android WebView", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        webView.setBackgroundColor(Color.rgb(16, 21, 34));
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        pageFrame.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        cursor = new RemoteCursorView(this);
        cursor.setClickable(false);
        cursor.setFocusable(false);
        pageFrame.addView(cursor, new FrameLayout.LayoutParams(-1, -1));
    }

    private StateListDrawable buttonBackground() {
        StateListDrawable state = new StateListDrawable();
        state.addState(new int[]{android.R.attr.state_focused}, rounded(PANEL, ACCENT, 3));
        state.addState(new int[]{android.R.attr.state_pressed}, rounded(Color.rgb(56, 78, 102), ACCENT, 2));
        state.addState(new int[]{}, rounded(PANEL, Color.rgb(45, 56, 74), 1));
        return state;
    }

    private StateListDrawable fieldBackground() {
        StateListDrawable state = new StateListDrawable();
        state.addState(new int[]{android.R.attr.state_focused},
                rounded(Color.rgb(35, 52, 68), ACCENT, 2));
        state.addState(new int[]{}, rounded(PANEL, Color.rgb(55, 69, 89), 1));
        return state;
    }

    private GradientDrawable rounded(int fill, int stroke, int strokeDp) {
        GradientDrawable background = new GradientDrawable();
        background.setColor(fill);
        background.setCornerRadius(dp(10));
        background.setStroke(dp(strokeDp), stroke);
        return background;
    }

    private Button addButton(LinearLayout toolbar, String text, String description,
                             int widthDp, Runnable action) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(text.length() > 3 ? 14 : 20);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setPadding(dp(2), 0, dp(2), 0);
        button.setContentDescription(description);
        button.setBackground(buttonBackground());
        button.setFocusable(true);
        button.setOnClickListener(view -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(widthDp), dp(52));
        params.setMargins(dp(3), 0, dp(3), 0);
        toolbar.addView(button, params);
        return button;
    }

    private void configureWebView() {
        if (webView == null) return;
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(110);
        defaultUserAgent = settings.getUserAgentString();
        setDesktopMode(desktopMode, false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                if ("http".equals(scheme) || "https".equals(scheme) || "about".equals(scheme)) {
                    return false;
                }
                if ("mailto".equals(scheme) || "tel".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                        toast("Нет приложения для открытия ссылки");
                    }
                    return true;
                }
                toast("Этот тип ссылки не поддерживается");
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                updateAddress(url);
                updateNavigationButtons();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                updateAddress(url);
                updateNavigationButtons();
                updateBookmarkButton();
                if (isHttpUrl(url) && !HOME_URL.equals(url)) {
                    preferences.edit().putString("last_url", url).apply();
                }
            }

            @Override
            public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                updateNavigationButtons();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) toast("Не удалось открыть страницу. Проверьте интернет.");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                updateBookmarkButton();
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullScreenView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                fullScreenView = view;
                fullScreenCallback = callback;
                toolbarScroll.setVisibility(View.GONE);
                progressBar.setVisibility(View.GONE);
                pageFrame.setVisibility(View.GONE);
                root.addView(view, new LinearLayout.LayoutParams(-1, 0, 1f));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                exitFullscreen();
            }
        });
        webView.setOnLongClickListener(view -> false);
    }

    private void exitFullscreen() {
        if (fullScreenView == null) return;
        root.removeView(fullScreenView);
        fullScreenView = null;
        toolbarScroll.setVisibility(View.VISIBLE);
        pageFrame.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (fullScreenCallback != null) {
            WebChromeClient.CustomViewCallback callback = fullScreenCallback;
            fullScreenCallback = null;
            callback.onCustomViewHidden();
        }
        webView.requestFocus();
    }

    private void showHome() {
        if (webView == null) return;
        try (InputStream in = getAssets().open("home.html");
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            String html = new String(out.toByteArray(), StandardCharsets.UTF_8);
            webView.loadDataWithBaseURL(HOME_URL, html, "text/html", "UTF-8", HOME_URL);
            addressBar.setText("");
            setCursorMode(true);
        } catch (Exception error) {
            toast("Не удалось загрузить домашнюю страницу");
        }
    }

    private void searchOrNavigate(String entry) {
        String input = entry == null ? "" : entry.trim();
        if (input.isEmpty()) {
            showHome();
            return;
        }
        String url;
        if (input.matches("(?i)^https?://\\S+$")) {
            url = input;
        } else if (input.matches("(?i)^(localhost|[a-z0-9-]+(\\.[a-z0-9-]+)+)(:[0-9]{1,5})?(/\\S*)?$")) {
            url = "https://" + input;
        } else {
            try {
                url = SEARCH_URL + URLEncoder.encode(input, "UTF-8");
            } catch (Exception impossible) {
                return;
            }
        }
        navigate(url);
    }

    private void navigate(String url) {
        if (!isHttpUrl(url) || webView == null) {
            toast("Можно открыть только HTTP/HTTPS-страницы");
            return;
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(addressBar.getWindowToken(), 0);
        webView.loadUrl(url);
        addressBar.setText(url);
        setCursorMode(true);
    }

    private boolean isHttpUrl(String url) {
        if (url == null) return false;
        try {
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            return ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme))
                    && uri.getHost() != null && !uri.getHost().isEmpty();
        } catch (Exception error) {
            return false;
        }
    }

    private void updateAddress(String url) {
        if (addressBar.hasFocus()) return;
        addressBar.setText(url == null || HOME_URL.equals(url) ? "" : url);
    }

    private void updateNavigationButtons() {
        if (webView == null) return;
        backButton.setAlpha(webView.canGoBack() ? 1f : .55f);
        forwardButton.setAlpha(webView.canGoForward() ? 1f : .55f);
    }

    private void setCursorMode(boolean enable) {
        cursorMode = enable;
        if (cursor == null || webView == null) return;
        cursor.setVisibility(enable ? View.VISIBLE : View.GONE);
        pointerButton.setText(enable ? "● Курсор" : "○ Фокус");
        if (enable) {
            webView.requestFocus();
        } else {
            backButton.requestFocus();
        }
    }

    private void moveCursor(int keyCode, int repeats) {
        float speed = dp(Math.min(58, 20 + (repeats / 2) * 5));
        float dx = keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ? speed
                : keyCode == KeyEvent.KEYCODE_DPAD_LEFT ? -speed : 0;
        float dy = keyCode == KeyEvent.KEYCODE_DPAD_DOWN ? speed
                : keyCode == KeyEvent.KEYCODE_DPAD_UP ? -speed : 0;
        cursor.move(dx, dy);
    }

    private void clickCursor() {
        if (webView == null) return;
        float x = cursor.getCursorX();
        float y = cursor.getCursorY();
        long t = SystemClock.uptimeMillis();
        MotionEvent down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
        down.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        webView.dispatchTouchEvent(down);
        down.recycle();
        MotionEvent up = MotionEvent.obtain(t, t + 65, MotionEvent.ACTION_UP, x, y, 0);
        up.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        webView.dispatchTouchEvent(up);
        up.recycle();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (webView == null) return super.dispatchKeyEvent(event);
        int code = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        if (fullScreenView != null) {
            if (code == KeyEvent.KEYCODE_BACK) {
                if (down) exitFullscreen();
                return true;
            }
            return super.dispatchKeyEvent(event);
        }
        if (code == KeyEvent.KEYCODE_MENU) {
            if (down) setCursorMode(false);
            return true;
        }
        if (down && event.isCtrlPressed() && code == KeyEvent.KEYCODE_L) {
            setCursorMode(false);
            addressBar.requestFocus();
            addressBar.selectAll();
            return true;
        }
        if (down && event.isCtrlPressed() && code == KeyEvent.KEYCODE_R) {
            webView.reload();
            return true;
        }
        if (code == KeyEvent.KEYCODE_CHANNEL_DOWN || code == KeyEvent.KEYCODE_PAGE_DOWN) {
            if (down) webView.pageDown(false);
            return true;
        }
        if (code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_PAGE_UP) {
            if (down) webView.pageUp(false);
            return true;
        }
        if (cursorMode && webView.hasFocus()) {
            if (code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
                    code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (down) moveCursor(code, event.getRepeatCount());
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER ||
                    code == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                if (down && event.getRepeatCount() == 0) clickCursor();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onBackPressed() {
        if (fullScreenView != null) {
            exitFullscreen();
        } else if (cursorMode) {
            setCursorMode(false);
        } else if (webView != null && webView.canGoBack()) {
            webView.goBack();
            setCursorMode(true);
        } else {
            super.onBackPressed();
        }
    }

    private static final class Bookmark {
        final String title;
        final String url;
        Bookmark(String title, String url) {
            this.title = title;
            this.url = url;
        }
    }

    private List<Bookmark> getBookmarks() {
        List<Bookmark> items = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(preferences.getString("bookmarks", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                String url = obj.optString("url", "");
                if (isHttpUrl(url)) items.add(new Bookmark(obj.optString("title", url), url));
            }
        } catch (Exception ignored) { }
        return items;
    }

    private void saveBookmarks(List<Bookmark> items) {
        JSONArray array = new JSONArray();
        try {
            for (Bookmark item : items) {
                JSONObject obj = new JSONObject();
                obj.put("title", item.title);
                obj.put("url", item.url);
                array.put(obj);
            }
        } catch (Exception ignored) { }
        preferences.edit().putString("bookmarks", array.toString()).apply();
        updateBookmarkButton();
    }

    private void toggleBookmark() {
        String url = webView.getUrl();
        if (!isHttpUrl(url) || HOME_URL.equals(url)) {
            toast("Откройте сайт, чтобы добавить закладку");
            return;
        }
        List<Bookmark> items = getBookmarks();
        for (int i = 0; i < items.size(); i++) {
            if (url.equals(items.get(i).url)) {
                items.remove(i);
                saveBookmarks(items);
                toast("Закладка удалена");
                return;
            }
        }
        if (items.size() >= 100) {
            toast("Можно сохранить до 100 закладок");
            return;
        }
        String title = webView.getTitle();
        if (title == null || title.trim().isEmpty()) title = Uri.parse(url).getHost();
        items.add(0, new Bookmark(title, url));
        saveBookmarks(items);
        toast("Добавлено в закладки");
    }

    private void updateBookmarkButton() {
        if (webView == null || bookmarkButton == null) return;
        String current = webView.getUrl();
        boolean saved = false;
        for (Bookmark item : getBookmarks()) {
            if (item.url.equals(current)) { saved = true; break; }
        }
        bookmarkButton.setText(saved ? "★" : "☆");
    }

    private void showBookmarks() {
        List<Bookmark> items = getBookmarks();
        if (items.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Закладки")
                    .setMessage("Сохранённых сайтов пока нет. Нажмите ☆ на открытой странице.")
                    .setPositiveButton("Понятно", null).show();
            return;
        }
        String[] labels = new String[items.size()];
        for (int i = 0; i < items.size(); i++) {
            String title = items.get(i).title;
            if (title.length() > 65) title = title.substring(0, 65) + "…";
            labels[i] = title + "\n" + items.get(i).url;
        }
        new AlertDialog.Builder(this)
                .setTitle("Закладки")
                .setItems(labels, (dialog, index) -> navigate(items.get(index).url))
                .setNeutralButton("Удалить…", (dialog, which) -> showRemoveBookmarks())
                .setNegativeButton("Закрыть", null)
                .show();
    }

    private void showRemoveBookmarks() {
        List<Bookmark> items = getBookmarks();
        if (items.isEmpty()) return;
        String[] titles = new String[items.size()];
        for (int i = 0; i < items.size(); i++) titles[i] = items.get(i).title;
        new AlertDialog.Builder(this)
                .setTitle("Удалить закладку")
                .setItems(titles, (dialog, index) -> {
                    items.remove(index);
                    saveBookmarks(items);
                    toast("Закладка удалена");
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void setDesktopMode(boolean desktop, boolean reload) {
        desktopMode = desktop;
        if (webView == null || defaultUserAgent == null) return;
        if (desktop) {
            Matcher matcher = Pattern.compile("Chrome/([0-9.]+)").matcher(defaultUserAgent);
            String chromeVersion = matcher.find() ? matcher.group(1) : "120.0.0.0";
            webView.getSettings().setUserAgentString(
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                            "(KHTML, like Gecko) Chrome/" + chromeVersion + " Safari/537.36");
        } else {
            webView.getSettings().setUserAgentString(defaultUserAgent);
        }
        preferences.edit().putBoolean("desktop", desktop).apply();
        if (reload) webView.reload();
    }

    private void showMenu() {
        String[] options = {
                desktopMode ? "Мобильная версия сайтов" : "Версия сайтов для ПК",
                "Прокрутка страницы вниз",
                "Прокрутка страницы вверх",
                "Очистить историю, cookies и кэш",
                "Управление пультом"
        };
        new AlertDialog.Builder(this).setTitle("Настройки")
                .setItems(options, (dialog, option) -> {
                    switch (option) {
                        case 0:
                            setDesktopMode(!desktopMode, true);
                            toast(desktopMode ? "Режим ПК включён" : "Мобильный режим включён");
                            break;
                        case 1: webView.pageDown(false); break;
                        case 2: webView.pageUp(false); break;
                        case 3: confirmClearData(); break;
                        case 4: showHelp(); break;
                        default: break;
                    }
                }).setNegativeButton("Закрыть", null).show();
    }

    private void showHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Управление пультом")
                .setMessage("КУРСОР: стрелки двигают указатель, OK нажимает. " +
                        "Удерживайте стрелку, чтобы двигаться быстрее.\n\n" +
                        "BACK: выйти из режима курсора. Ещё раз BACK — назад по истории.\n\n" +
                        "MENU: перейти к верхней панели. В панели стрелки переключают кнопки.\n\n" +
                        "CH+/CH− или PAGE UP/PAGE DOWN: прокрутить страницу. " +
                        "Также можно выбрать прокрутку через меню ⋮.\n\n" +
                        "☆: добавить или удалить текущую закладку. ★: список закладок.\n\n" +
                        "Если есть клавиатура: Ctrl+L — адрес, Ctrl+R — обновить.")
                .setPositiveButton("Понятно", null).show();
    }

    private void confirmClearData() {
        new AlertDialog.Builder(this)
                .setTitle("Очистить данные?")
                .setMessage("Удалятся история открытых страниц, cookies, " +
                        "данные сайтов и кэш. Закладки сохранятся.")
                .setPositiveButton("Очистить", (dialog, which) -> {
                    webView.clearHistory();
                    webView.clearCache(true);
                    webView.clearFormData();
                    WebStorage.getInstance().deleteAllData();
                    CookieManager.getInstance().removeAllCookies(value -> CookieManager.getInstance().flush());
                    preferences.edit().remove("last_url").apply();
                    showHome();
                    toast("Данные браузера очищены");
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            pageFrame.removeView(webView);
            webView.destroy();
        }
        super.onDestroy();
    }
}
